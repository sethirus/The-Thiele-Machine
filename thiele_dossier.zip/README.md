# Thiele Machine Experiments

This directory contains automated experiments to empirically validate the Thiele Machine's information-theoretic cost model (μ-spec).

## Quick Verification (2 minutes)

1. Run a small sweep:
   ```bash
   python ../run_partition_experiments.py --problem tseitin --partitions 6 8 10 --repeat 2
   ```

2. Check plots: `tseitin_mu_plot.png` and `tseitin_ratio_plot.png`
   - Blind μ should rise exponentially
   - Sighted μ should be roughly constant
   - Ratio should increase with n

3. Verify scaling report: `tseitin_scaling_report_*.json`
   - Exp fit R² > 0.9 for blind
   - Poly slope near zero for sighted
   - Ratio slope > 0

## Hypotheses Tested

See `hypotheses.yaml` for pre-registered hypotheses.

## Reproducing Full Results

For comprehensive evidence:
```bash
python ../run_partition_experiments.py \
  --problem tseitin \
  --partitions 6 8 10 12 14 16 18 20 \
  --repeat 10 \
  --seed-grid 0 1 2 3 4 5 6 7 8 9
```

This generates reproducible receipts with SHA256 hashes.