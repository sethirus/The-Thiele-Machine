"""Archived hostile-family benchmark harness (skipped in CI)."""

from __future__ import annotations

import pytest

pytest.skip("hostile families benchmark requires manual execution", allow_module_level=True)