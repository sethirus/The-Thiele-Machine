x = -9
print(f'Preparing call: x = {x}')
