print('Testing partition:')
print('  - All pieces: {A, B, C, D}')
