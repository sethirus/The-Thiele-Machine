print('Testing partition:')
print('  - Color d=0: {A, B, C} (assume color d = 0)')
print('  - Color d=1: {D} (assume color d = 1)')
