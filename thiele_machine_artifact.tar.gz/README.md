# The Thiele Machine: Archival Artifact

This is the archival artifact for the paper "The Thiele Machine: A Formal Model of Computation with Provable Consistency".

## Contents

- `documents/The_Thiele_Machine.tex`: The final LaTeX source of the paper
- `documents/The_Thiele_Machine.pdf`: The compiled PDF of the paper
- `coq/`: Complete Coq source files and build system
- `scripts/`: Python scripts for empirical experiments
- `results/`: Experimental results and receipts

## Building the Coq Proofs

### Requirements

- Coq version 8.18.0 (compiled with OCaml 4.14.1)
- GNU Make

### Build Instructions

1. Navigate to the `coq` directory:
   ```
   cd coq
   ```

2. Build the proofs:
   ```
   make
   ```

This will compile all the Coq source files and verify the mechanized proofs.

## Reproducing Experiments

See the `scripts/` directory for Python scripts to reproduce the empirical experiments described in the paper.

## License

This work is provided as-is for academic and research purposes.