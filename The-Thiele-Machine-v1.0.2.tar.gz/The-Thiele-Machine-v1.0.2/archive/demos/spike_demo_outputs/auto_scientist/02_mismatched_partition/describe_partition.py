print('Testing partition:')
print('  - Group 1: {A, B} (assume color d = 0)')
print('  - Group 2: {C, D} (assume color d = 1)')
