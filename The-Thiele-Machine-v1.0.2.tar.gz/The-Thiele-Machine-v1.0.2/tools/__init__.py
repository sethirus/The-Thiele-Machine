"""Support utilities for the Thiele Machine artifact."""

