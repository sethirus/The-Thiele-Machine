Thiele Machine™ and Thiele CPU™ are names used by Devon Thiele to identify an
open, auditable architecture. You may describe accurate compatibility (e.g.,
"Thiele-compatible") and you may use the names to refer to this project. You
may not imply sponsorship or endorsement, or use the names as your own brand.